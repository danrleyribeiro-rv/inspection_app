// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'signature_data.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SignatureData _$SignatureDataFromJson(Map<String, dynamic> json) =>
    SignatureData(
      id: json['id'] as String,
      inspectionId: json['inspectionId'] as String,
      name: json['name'] as String,
      lastName: json['lastName'] as String,
      document: json['document'] as String,
      email: json['email'] as String,
      address: Address.fromJson(json['address'] as Map<String, dynamic>),
      signatureUrl: json['signatureUrl'] as String,
      motive: json['motive'] as String,
      customMotive: json['customMotive'] as String?,
      createdAt: SignatureData._timestampFromJson(json['createdAt']),
      updatedAt: SignatureData._timestampFromJson(json['updatedAt']),
    );

Map<String, dynamic> _$SignatureDataToJson(SignatureData instance) =>
    <String, dynamic>{
      'id': instance.id,
      'inspectionId': instance.inspectionId,
      'name': instance.name,
      'lastName': instance.lastName,
      'document': instance.document,
      'email': instance.email,
      'address': instance.address,
      'signatureUrl': instance.signatureUrl,
      'motive': instance.motive,
      'customMotive': instance.customMotive,
      'createdAt': SignatureData._timestampToJson(instance.createdAt),
      'updatedAt': SignatureData._timestampToJson(instance.updatedAt),
    };

Address _$AddressFromJson(Map<String, dynamic> json) => Address(
      cep: json['cep'] as String,
      street: json['street'] as String,
      number: json['number'] as String,
      complement: json['complement'] as String?,
      neighborhood: json['neighborhood'] as String,
      city: json['city'] as String,
      state: json['state'] as String,
      useInspectionAddress: json['useInspectionAddress'] as bool? ?? false,
    );

Map<String, dynamic> _$AddressToJson(Address instance) => <String, dynamic>{
      'cep': instance.cep,
      'street': instance.street,
      'number': instance.number,
      'complement': instance.complement,
      'neighborhood': instance.neighborhood,
      'city': instance.city,
      'state': instance.state,
      'useInspectionAddress': instance.useInspectionAddress,
    };
