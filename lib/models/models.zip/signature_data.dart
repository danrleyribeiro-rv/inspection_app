import 'package:json_annotation/json_annotation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

part 'signature_data.g.dart';

@JsonSerializable()
class SignatureData {
  final String id;
  final String inspectionId;
  final String name;
  final String lastName;
  final String document; // CPF/CNPJ
  final String email;
  final Address address;
  final String signatureUrl; // URL da assinatura no Storage
  final String motive;
  final String? customMotive; // Para quando motivo é "Outro"
  
  @JsonKey(
    fromJson: _timestampFromJson,
    toJson: _timestampToJson,
  )
  final DateTime createdAt;

  @JsonKey(
    fromJson: _timestampFromJson,
    toJson: _timestampToJson,
  )
  final DateTime updatedAt;

  const SignatureData({
    required this.id,
    required this.inspectionId,
    required this.name,
    required this.lastName,
    required this.document,
    required this.email,
    required this.address,
    required this.signatureUrl,
    required this.motive,
    this.customMotive,
    required this.createdAt,
    required this.updatedAt,
  });

  factory SignatureData.fromJson(Map<String, dynamic> json) => _$SignatureDataFromJson(json);

  Map<String, dynamic> toJson() => _$SignatureDataToJson(this);

  factory SignatureData.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return SignatureData.fromJson({
      'id': doc.id,
      ...data,
    });
  }

  Map<String, dynamic> toFirestore() {
    final json = toJson();
    json.remove('id'); // Remove ID for Firestore
    return json;
  }

  SignatureData copyWith({
    String? id,
    String? inspectionId,
    String? name,
    String? lastName,
    String? document,
    String? email,
    Address? address,
    String? signatureUrl,
    String? motive,
    String? customMotive,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return SignatureData(
      id: id ?? this.id,
      inspectionId: inspectionId ?? this.inspectionId,
      name: name ?? this.name,
      lastName: lastName ?? this.lastName,
      document: document ?? this.document,
      email: email ?? this.email,
      address: address ?? this.address,
      signatureUrl: signatureUrl ?? this.signatureUrl,
      motive: motive ?? this.motive,
      customMotive: customMotive ?? this.customMotive,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  static DateTime _timestampFromJson(dynamic timestamp) {
    if (timestamp == null) return DateTime.now();
    
    if (timestamp is Timestamp) {
      return timestamp.toDate();
    }
    
    if (timestamp is Map<String, dynamic>) {
      final seconds = timestamp['_seconds'] as int?;
      final nanoseconds = timestamp['_nanoseconds'] as int?;
      if (seconds != null) {
        return DateTime.fromMillisecondsSinceEpoch(
          seconds * 1000 + (nanoseconds ?? 0) ~/ 1000000
        );
      }
    }
    
    if (timestamp is String) {
      return DateTime.tryParse(timestamp) ?? DateTime.now();
    }
    
    return DateTime.now();
  }

  static dynamic _timestampToJson(DateTime dateTime) {
    return Timestamp.fromDate(dateTime);
  }
}

@JsonSerializable()
class Address {
  final String cep;
  final String street;
  final String number;
  final String? complement;
  final String neighborhood;
  final String city;
  final String state;
  final bool useInspectionAddress; // Se true, usar endereço da vistoria

  const Address({
    required this.cep,
    required this.street,
    required this.number,
    this.complement,
    required this.neighborhood,
    required this.city,
    required this.state,
    this.useInspectionAddress = false,
  });

  factory Address.fromJson(Map<String, dynamic> json) => _$AddressFromJson(json);

  Map<String, dynamic> toJson() => _$AddressToJson(this);

  Address copyWith({
    String? cep,
    String? street,
    String? number,
    String? complement,
    String? neighborhood,
    String? city,
    String? state,
    bool? useInspectionAddress,
  }) {
    return Address(
      cep: cep ?? this.cep,
      street: street ?? this.street,
      number: number ?? this.number,
      complement: complement ?? this.complement,
      neighborhood: neighborhood ?? this.neighborhood,
      city: city ?? this.city,
      state: state ?? this.state,
      useInspectionAddress: useInspectionAddress ?? this.useInspectionAddress,
    );
  }

  String get formattedAddress {
    final parts = [
      street,
      number,
      if (complement?.isNotEmpty == true) complement,
      neighborhood,
      city,
      state,
    ].where((part) => part?.isNotEmpty == true);
    
    return parts.join(', ');
  }
}

// Enum para motivos predefinidos
enum SignatureMotive {
  termoConsentimento('Termo de Consentimento'),
  vistoriaCautelar('Vistoria Cautelar'),
  vnr('VNR'),
  outro('Outro');

  const SignatureMotive(this.displayName);
  final String displayName;

  static SignatureMotive fromString(String value) {
    switch (value.toLowerCase()) {
      case 'termo de consentimento':
        return SignatureMotive.termoConsentimento;
      case 'vistoria cautelar':
        return SignatureMotive.vistoriaCautelar;
      case 'vnr':
        return SignatureMotive.vnr;
      case 'outro':
        return SignatureMotive.outro;
      default:
        return SignatureMotive.outro;
    }
  }

  static List<SignatureMotive> get allValues => [
    SignatureMotive.termoConsentimento,
    SignatureMotive.vistoriaCautelar,
    SignatureMotive.vnr,
    SignatureMotive.outro,
  ];
}