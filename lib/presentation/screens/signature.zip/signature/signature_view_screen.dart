import 'package:flutter/material.dart';
import 'dart:io';
import 'package:lince_inspecoes/models/signature_data.dart';
import 'package:lince_inspecoes/services/signature_service.dart';
import 'package:lince_inspecoes/presentation/screens/signature/signature_registration_screen.dart';

class SignatureViewScreen extends StatefulWidget {
  final String inspectionId;

  const SignatureViewScreen({
    super.key,
    required this.inspectionId,
  });

  @override
  State<SignatureViewScreen> createState() => _SignatureViewScreenState();
}

class _SignatureViewScreenState extends State<SignatureViewScreen> {
  final SignatureService _signatureService = SignatureService();
  SignatureData? _signatureData;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadSignature();
  }

  Future<void> _loadSignature() async {
    try {
      final signature = await _signatureService.getSignatureData(widget.inspectionId);
      if (mounted) {
        setState(() {
          _signatureData = signature;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Erro ao carregar assinatura: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _editSignature() async {
    final result = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (context) => SignatureRegistrationScreen(
          inspectionId: widget.inspectionId,
        ),
      ),
    );

    if (result == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Assinatura atualizada com sucesso!'),
          backgroundColor: Colors.green,
        ),
      );
      Navigator.of(context).pop(true);
    }
  }

  Future<void> _deleteSignature() async {
    final shouldDelete = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Excluir Assinatura'),
        content: const Text(
          'Tem certeza que deseja excluir esta assinatura? '
          'Esta ação não pode ser desfeita.'
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );

    if (shouldDelete == true && _signatureData != null) {
      try {
        await _signatureService.deleteSignature(
          widget.inspectionId, 
          _signatureData!.id
        );
        
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Assinatura excluída com sucesso!'),
              backgroundColor: Colors.green,
            ),
          );
          Navigator.of(context).pop(true);
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Erro ao excluir assinatura: $e'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Assinatura Registrada'),
        backgroundColor: const Color(0xFF312456),
        actions: [
          if (!_isLoading && _signatureData != null) ...[
            IconButton(
              onPressed: _editSignature,
              icon: const Icon(Icons.edit),
              tooltip: 'Editar Assinatura',
            ),
            IconButton(
              onPressed: _deleteSignature,
              icon: const Icon(Icons.delete),
              tooltip: 'Excluir Assinatura',
            ),
          ],
        ],
      ),
      backgroundColor: const Color(0xFF312456),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFF6F4B99)),
            )
          : _signatureData == null
              ? _buildNoSignatureFound()
              : _buildSignatureView(),
      floatingActionButton: !_isLoading && _signatureData == null
          ? FloatingActionButton.extended(
              onPressed: _editSignature,
              backgroundColor: const Color(0xFF6F4B99),
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add),
              label: const Text('Nova Assinatura'),
            )
          : null,
    );
  }

  Widget _buildNoSignatureFound() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.edit,
            size: 64,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'Nenhuma assinatura encontrada',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey[300],
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Toque no botão abaixo para registrar uma nova assinatura',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[400],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildSignatureView() {
    final signature = _signatureData!;
    
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Signature Image
          Container(
            width: double.infinity,
            height: 200,
            margin: const EdgeInsets.only(bottom: 24),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF6F4B99), width: 2),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  spreadRadius: 1,
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: _buildSignatureImage(signature.signatureUrl),
            ),
          ),

          // Signature Details
          _buildInfoSection('Dados Pessoais', Icons.person, [
            _buildInfoRow('Nome', '${signature.name} ${signature.lastName}'),
            _buildInfoRow('Documento', signature.document),
            _buildInfoRow('Email', signature.email),
          ]),

          const SizedBox(height: 16),

          _buildInfoSection('Endereço', Icons.location_on, [
            _buildInfoRow('Endereço', signature.address.formattedAddress),
            _buildInfoRow('CEP', signature.address.cep),
            if (signature.address.complement?.isNotEmpty == true)
              _buildInfoRow('Complemento', signature.address.complement!),
          ]),

          const SizedBox(height: 16),

          _buildInfoSection('Motivo', Icons.description, [
            _buildInfoRow('Motivo', signature.motive),
            if (signature.customMotive?.isNotEmpty == true)
              _buildInfoRow('Motivo Customizado', signature.customMotive!),
          ]),

          const SizedBox(height: 16),

          _buildInfoSection('Informações Adicionais', Icons.info, [
            _buildInfoRow('Data de Registro', _formatDate(signature.createdAt)),
            _buildInfoRow('Última Atualização', _formatDate(signature.updatedAt)),
            _buildInfoRow('ID da Assinatura', signature.id),
          ]),

          const SizedBox(height: 24),

          // Action Buttons
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _editSignature,
                  icon: const Icon(Icons.edit),
                  label: const Text('Editar'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF6F4B99),
                    side: const BorderSide(color: Color(0xFF6F4B99)),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: _deleteSignature,
                  icon: const Icon(Icons.delete),
                  label: const Text('Excluir'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ],
          ),

          SizedBox(height: MediaQuery.of(context).padding.bottom + 16),
        ],
      ),
    );
  }

  Widget _buildInfoSection(String title, IconData icon, List<Widget> children) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withAlpha((255 * 0.05).round()),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF6F4B99).withAlpha((255 * 0.3).round())),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: const Color(0xFF6F4B99), size: 20),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF6F4B99),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w600,
                color: Colors.white70,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 14,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/'
           '${date.month.toString().padLeft(2, '0')}/'
           '${date.year} às '
           '${date.hour.toString().padLeft(2, '0')}:'
           '${date.minute.toString().padLeft(2, '0')}';
  }

  Widget _buildSignatureImage(String signatureUrl) {
    debugPrint('Loading signature image: $signatureUrl');
    
    // Handle different URL types
    if (signatureUrl.startsWith('http')) {
      // Firebase Storage URL
      return Image.network(
        signatureUrl,
        fit: BoxFit.contain,
        loadingBuilder: (context, child, loadingProgress) {
          if (loadingProgress == null) return child;
          return const Center(
            child: CircularProgressIndicator(
              color: Color(0xFF6F4B99),
            ),
          );
        },
        errorBuilder: (context, error, stackTrace) {
          debugPrint('Error loading network image: $error');
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.broken_image, size: 48, color: Colors.grey),
                SizedBox(height: 8),
                Text('Erro ao carregar assinatura', style: TextStyle(color: Colors.grey)),
              ],
            ),
          );
        },
      );
    } else if (signatureUrl.startsWith('file://')) {
      // Local file URL
      final filePath = signatureUrl.substring(7); // Remove 'file://'
      return Image.file(
        File(filePath),
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) {
          debugPrint('Error loading local image: $error');
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.broken_image, size: 48, color: Colors.grey),
                SizedBox(height: 8),
                Text('Erro ao carregar arquivo local', style: TextStyle(color: Colors.grey)),
              ],
            ),
          );
        },
      );
    } else if (signatureUrl.startsWith('/')) {
      // Absolute local path
      return Image.file(
        File(signatureUrl),
        fit: BoxFit.contain,
        errorBuilder: (context, error, stackTrace) {
          debugPrint('Error loading local image: $error');
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.broken_image, size: 48, color: Colors.grey),
                SizedBox(height: 8),
                Text('Arquivo não encontrado', style: TextStyle(color: Colors.grey)),
              ],
            ),
          );
        },
      );
    } else {
      // Unknown format
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.help_outline, size: 48, color: Colors.grey),
            const SizedBox(height: 8),
            Text(
              'Formato de URL não reconhecido:\n$signatureUrl',
              style: const TextStyle(color: Colors.grey, fontSize: 12),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }
  }
}