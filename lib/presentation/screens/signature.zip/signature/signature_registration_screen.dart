import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:brasil_fields/brasil_fields.dart';
import 'package:cpf_cnpj_validator/cpf_validator.dart' as cpf_validator;
import 'package:cpf_cnpj_validator/cnpj_validator.dart' as cnpj_validator;
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:uuid/uuid.dart';
import 'package:lince_inspecoes/models/signature_data.dart';
import 'package:lince_inspecoes/models/inspection.dart';
import 'package:lince_inspecoes/services/enhanced_offline_service_factory.dart';
import 'package:lince_inspecoes/services/signature_service.dart';
import 'package:lince_inspecoes/presentation/screens/signature/signature_pad_dialog.dart';

class SignatureRegistrationScreen extends StatefulWidget {
  final String inspectionId;

  const SignatureRegistrationScreen({
    super.key,
    required this.inspectionId,
  });

  @override
  State<SignatureRegistrationScreen> createState() => _SignatureRegistrationScreenState();
}

class _SignatureRegistrationScreenState extends State<SignatureRegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _documentController = TextEditingController();
  final _cepController = TextEditingController();
  final _streetController = TextEditingController();
  final _numberController = TextEditingController();
  final _complementController = TextEditingController();
  final _neighborhoodController = TextEditingController();
  final _cityController = TextEditingController();
  final _stateController = TextEditingController();
  final _customMotiveController = TextEditingController();

  final EnhancedOfflineServiceFactory _serviceFactory = EnhancedOfflineServiceFactory.instance;
  final SignatureService _signatureService = SignatureService();
  
  SignatureMotive _selectedMotive = SignatureMotive.termoConsentimento;
  bool _useInspectionAddress = true;
  bool _isCepLoading = false;
  bool _isLoading = false;
  Inspection? _inspection;
  String? _signatureImagePath;

  @override
  void initState() {
    super.initState();
    _loadInspection();
  }

  Future<void> _loadInspection() async {
    try {
      final inspection = await _serviceFactory.dataService.getInspection(widget.inspectionId);
      if (mounted && inspection != null) {
        setState(() {
          _inspection = inspection;
        });
        
        // Auto-fill address if using inspection address
        if (_useInspectionAddress && inspection.addressString?.isNotEmpty == true) {
          _fillInspectionAddress();
        }
      }
    } catch (e) {
      debugPrint('Error loading inspection: $e');
    }
  }

  void _fillInspectionAddress() {
    if (_inspection?.addressString != null) {
      // Try to parse inspection address
      final addressParts = _inspection!.addressString!.split(', ');
      if (addressParts.length >= 4) {
        setState(() {
          _streetController.text = addressParts[0];
          _numberController.text = addressParts.length > 1 ? addressParts[1] : '';
          _neighborhoodController.text = addressParts.length > 2 ? addressParts[2] : '';
          _cityController.text = addressParts.length > 3 ? addressParts[3].split(' - ')[0] : '';
          _stateController.text = addressParts.length > 3 && addressParts[3].contains(' - ') 
            ? addressParts[3].split(' - ')[1] 
            : '';
        });
      }
    }
  }

  Future<void> _fetchCepData(String cep) async {
    final cepDigits = cep.replaceAll(RegExp(r'\D'), '');
    if (cepDigits.length != 8) return;

    setState(() => _isCepLoading = true);

    try {
      final url = Uri.parse('https://viacep.com.br/ws/$cepDigits/json/');
      final response = await http.get(url);

      if (!mounted) return;

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data.containsKey('erro') && data['erro'] == true) {
          _showSnackBar('CEP não encontrado', Colors.orange);
        } else {
          setState(() {
            _streetController.text = data['logradouro'] ?? '';
            _neighborhoodController.text = data['bairro'] ?? '';
            _cityController.text = data['localidade'] ?? '';
            _stateController.text = data['uf'] ?? '';
          });
          _showSnackBar('Endereço preenchido automaticamente', Colors.green);
        }
      } else {
        _showSnackBar('Erro ao buscar CEP: ${response.statusCode}', Colors.red);
      }
    } catch (e) {
      if (!mounted) return;
      _showSnackBar('Erro ao buscar CEP: $e', Colors.red);
    } finally {
      if (mounted) {
        setState(() => _isCepLoading = false);
      }
    }
  }

  void _showSnackBar(String message, Color color) {
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: color,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  Future<void> _openSignaturePad() async {
    final signatureResult = await showDialog<String>(
      context: context,
      builder: (context) => const SignaturePadDialog(),
    );

    if (signatureResult != null && mounted) {
      setState(() {
        _signatureImagePath = signatureResult;
      });
    }
  }

  Future<void> _saveSignature() async {
    if (!_formKey.currentState!.validate()) return;

    if (_signatureImagePath == null) {
      _showSnackBar('Por favor, colete a assinatura', Colors.red);
      return;
    }

    // Validate document
    final documentValue = _documentController.text;
    final documentDigits = documentValue.replaceAll(RegExp(r'\D'), '');
    bool isDocumentValid = false;
    
    if (documentDigits.isNotEmpty) {
      if (documentDigits.length == 11) {
        isDocumentValid = cpf_validator.CPFValidator.isValid(documentValue);
        if (!isDocumentValid) {
          _showSnackBar('O CPF informado é inválido', Colors.red);
          return;
        }
      } else if (documentDigits.length == 14) {
        isDocumentValid = cnpj_validator.CNPJValidator.isValid(documentValue);
        if (!isDocumentValid) {
          _showSnackBar('O CNPJ informado é inválido', Colors.red);
          return;
        }
      } else {
        _showSnackBar('O documento deve ser um CPF (11 dígitos) ou CNPJ (14 dígitos)', Colors.red);
        return;
      }
    } else {
      _showSnackBar('Por favor, insira seu CPF ou CNPJ', Colors.red);
      return;
    }

    setState(() => _isLoading = true);

    try {
      // Create signature data
      final address = Address(
        cep: _cepController.text.replaceAll(RegExp(r'\D'), ''),
        street: _streetController.text.trim(),
        number: _numberController.text.trim(),
        complement: _complementController.text.trim().isNotEmpty 
          ? _complementController.text.trim() 
          : null,
        neighborhood: _neighborhoodController.text.trim(),
        city: _cityController.text.trim(),
        state: _stateController.text.trim().toUpperCase(),
        useInspectionAddress: _useInspectionAddress,
      );

      // Upload signature to Firebase Storage first
      final signatureUrl = await _uploadSignatureToStorage(_signatureImagePath!);
      
      final signatureData = SignatureData(
        id: const Uuid().v4(),
        inspectionId: widget.inspectionId,
        name: _nameController.text.trim(),
        lastName: _lastNameController.text.trim(),
        document: documentDigits,
        email: _emailController.text.trim(),
        address: address,
        signatureUrl: signatureUrl,
        motive: _selectedMotive.displayName,
        customMotive: _selectedMotive == SignatureMotive.outro 
          ? _customMotiveController.text.trim() 
          : null,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );

      // Save to Firestore
      await _saveToFirestore(signatureData);

      if (mounted) {
        _showSnackBar('Assinatura registrada com sucesso!', Colors.green);
        Navigator.of(context).pop(true);
      }
    } catch (e) {
      if (mounted) {
        _showSnackBar('Erro ao salvar assinatura: $e', Colors.red);
      }
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  Future<String> _uploadSignatureToStorage(String imagePath) async {
    return await _signatureService.uploadSignature(widget.inspectionId, imagePath);
  }

  Future<void> _saveToFirestore(SignatureData signatureData) async {
    await _signatureService.saveSignatureData(signatureData);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Registrar Assinatura'),
        backgroundColor: const Color(0xFF312456),
      ),
      backgroundColor: const Color(0xFF312456),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildSectionHeader('Dados Pessoais', Icons.person),
              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    child: _buildTextField(
                      controller: _nameController,
                      label: 'Nome',
                      icon: Icons.person_outline,
                      textCapitalization: TextCapitalization.words,
                      validator: (value) => value?.trim().isEmpty == true
                          ? 'Por favor, insira o nome'
                          : null,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildTextField(
                      controller: _lastNameController,
                      label: 'Sobrenome',
                      icon: Icons.person_outline,
                      textCapitalization: TextCapitalization.words,
                      validator: (value) => value?.trim().isEmpty == true
                          ? 'Por favor, insira o sobrenome'
                          : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              _buildTextField(
                controller: _documentController,
                label: 'CPF/CNPJ',
                icon: Icons.badge_outlined,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  CpfOuCnpjFormatter(),
                ],
                hintText: 'Digite o CPF ou CNPJ',
                validator: (value) {
                  if (value?.trim().isEmpty == true) {
                    return 'Por favor, insira seu CPF ou CNPJ';
                  }
                  final digits = value!.replaceAll(RegExp(r'\D'), '');
                  if (digits.length != 11 && digits.length != 14) {
                    return 'Insira 11 dígitos para CPF ou 14 para CNPJ';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              _buildTextField(
                controller: _emailController,
                label: 'Email',
                icon: Icons.email_outlined,
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value?.trim().isEmpty == true) {
                    return 'Por favor, insira o email';
                  }
                  final emailRegex = RegExp(r'^[^@]+@[^@]+\.[^@]+');
                  if (!emailRegex.hasMatch(value!.trim())) {
                    return 'Por favor, insira um email válido';
                  }
                  return null;
                },
              ),

              const SizedBox(height: 32),

              _buildSectionHeader('Endereço', Icons.location_on),
              const SizedBox(height: 16),

              // Address toggle
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF6F4B99).withAlpha((255 * 0.1).round()),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    Checkbox(
                      value: _useInspectionAddress,
                      onChanged: (value) {
                        setState(() {
                          _useInspectionAddress = value ?? true;
                          if (_useInspectionAddress) {
                            _fillInspectionAddress();
                          } else {
                            // Clear address fields
                            _cepController.clear();
                            _streetController.clear();
                            _numberController.clear();
                            _complementController.clear();
                            _neighborhoodController.clear();
                            _cityController.clear();
                            _stateController.clear();
                          }
                        });
                      },
                      activeColor: const Color(0xFF6F4B99),
                    ),
                    const Expanded(
                      child: Text(
                        'Usar endereço da vistoria',
                        style: TextStyle(color: Colors.white70, fontSize: 14),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              if (!_useInspectionAddress) ...[
                _buildTextField(
                  controller: _cepController,
                  label: 'CEP',
                  icon: Icons.location_on_outlined,
                  keyboardType: TextInputType.number,
                  inputFormatters: [
                    FilteringTextInputFormatter.digitsOnly,
                    CepInputFormatter(),
                  ],
                  hintText: '00.000-000',
                  suffixIcon: _isCepLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : IconButton(
                          icon: const Icon(Icons.search),
                          onPressed: () {
                            final cep = _cepController.text;
                            if (cep.isNotEmpty) {
                              _fetchCepData(cep);
                            } else {
                              _showSnackBar('Por favor, insira um CEP primeiro', Colors.orange);
                            }
                          },
                          tooltip: 'Buscar endereço',
                        ),
                  onChanged: (value) {
                    final digitsOnly = value.replaceAll(RegExp(r'\D'), '');
                    if (digitsOnly.length == 8) {
                      _fetchCepData(digitsOnly);
                    }
                  },
                  validator: (value) {
                    if (value?.trim().isEmpty == true) {
                      return 'Por favor, insira o CEP';
                    }
                    final digits = value!.replaceAll(RegExp(r'\D'), '');
                    if (digits.length != 8) {
                      return 'O CEP deve ter 8 dígitos';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),
              ],

              Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: _buildTextField(
                      controller: _streetController,
                      label: 'Rua',
                      icon: Icons.location_city_outlined,
                      textCapitalization: TextCapitalization.words,
                      validator: (value) => value?.trim().isEmpty == true
                          ? 'Por favor, insira a rua'
                          : null,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildTextField(
                      controller: _numberController,
                      label: 'Número',
                      icon: Icons.numbers,
                      validator: (value) => value?.trim().isEmpty == true
                          ? 'Por favor, insira o número'
                          : null,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),

              _buildTextField(
                controller: _complementController,
                label: 'Complemento (Opcional)',
                icon: Icons.location_city_outlined,
                textCapitalization: TextCapitalization.words,
              ),
              const SizedBox(height: 16),

              _buildTextField(
                controller: _neighborhoodController,
                label: 'Bairro',
                icon: Icons.location_city_outlined,
                textCapitalization: TextCapitalization.words,
                validator: (value) => value?.trim().isEmpty == true
                    ? 'Por favor, insira o bairro'
                    : null,
              ),
              const SizedBox(height: 16),

              Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: _buildTextField(
                      controller: _cityController,
                      label: 'Cidade',
                      icon: Icons.location_city,
                      textCapitalization: TextCapitalization.words,
                      validator: (value) => value?.trim().isEmpty == true
                          ? 'Por favor, insira a cidade'
                          : null,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _buildTextField(
                      controller: _stateController,
                      label: 'UF',
                      icon: Icons.map_outlined,
                      textCapitalization: TextCapitalization.characters,
                      inputFormatters: [
                        LengthLimitingTextInputFormatter(2),
                      ],
                      hintText: 'UF',
                      validator: (value) {
                        if (value?.trim().isEmpty == true) {
                          return 'Por favor, insira o estado';
                        }
                        if (value!.trim().length != 2) {
                          return 'Use 2 letras para o UF';
                        }
                        return null;
                      },
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 32),

              _buildSectionHeader('Assinatura', Icons.edit),
              const SizedBox(height: 16),

              // Signature collection button
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: _signatureImagePath != null 
                    ? Colors.green.withAlpha((255 * 0.1).round())
                    : Colors.grey.withAlpha((255 * 0.1).round()),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: _signatureImagePath != null 
                      ? Colors.green
                      : Colors.grey,
                  ),
                ),
                child: InkWell(
                  onTap: _openSignaturePad,
                  child: Column(
                    children: [
                      Icon(
                        _signatureImagePath != null 
                          ? Icons.check_circle 
                          : Icons.edit,
                        size: 48,
                        color: _signatureImagePath != null 
                          ? Colors.green
                          : Colors.grey,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _signatureImagePath != null 
                          ? 'Assinatura coletada'
                          : 'Toque para coletar assinatura',
                        style: TextStyle(
                          color: _signatureImagePath != null 
                            ? Colors.green
                            : Colors.grey,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 32),

              _buildSectionHeader('Motivo', Icons.description),
              const SizedBox(height: 16),

              // Motive dropdown
              DropdownButtonFormField<SignatureMotive>(
                value: _selectedMotive,
                decoration: InputDecoration(
                  labelText: 'Motivo',
                  prefixIcon: const Icon(Icons.description_outlined, color: Color(0xFF6F4B99)),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.grey[600]!),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: Color(0xFF6F4B99), width: 2),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.grey[600]!),
                  ),
                  filled: true,
                  fillColor: Colors.white10,
                  labelStyle: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
                style: const TextStyle(color: Colors.white, fontSize: 12),
                dropdownColor: Colors.grey[800],
                items: SignatureMotive.allValues.map((motive) {
                  return DropdownMenuItem<SignatureMotive>(
                    value: motive,
                    child: Text(
                      motive.displayName,
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedMotive = value ?? SignatureMotive.termoConsentimento;
                  });
                },
              ),

              if (_selectedMotive == SignatureMotive.outro) ...[
                const SizedBox(height: 16),
                _buildTextField(
                  controller: _customMotiveController,
                  label: 'Descreva o motivo',
                  icon: Icons.edit_outlined,
                  textCapitalization: TextCapitalization.sentences,
                  maxLines: 3,
                  validator: (value) => value?.trim().isEmpty == true
                      ? 'Por favor, descreva o motivo'
                      : null,
                ),
              ],

              const SizedBox(height: 40),

              // Save button
              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _saveSignature,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF6F4B99),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.save, size: 20),
                            SizedBox(width: 8),
                            Text(
                              'Salvar Assinatura',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                ),
              ),

              SizedBox(height: MediaQuery.of(context).padding.bottom + 24),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(String title, IconData icon) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 12),
      decoration: BoxDecoration(
        color: const Color(0xFF6F4B99).withAlpha((255 * 0.1).round()),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
            color: const Color(0xFF6F4B99).withAlpha((255 * 0.3).round())),
      ),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFF6F4B99), size: 20),
          const SizedBox(width: 8),
          Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Color(0xFF6F4B99),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hintText,
    TextInputType? keyboardType,
    List<TextInputFormatter>? inputFormatters,
    String? Function(String?)? validator,
    bool obscureText = false,
    Widget? suffixIcon,
    TextCapitalization textCapitalization = TextCapitalization.none,
    void Function(String)? onChanged,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        hintText: hintText,
        prefixIcon: Icon(icon, color: const Color(0xFF6F4B99)),
        suffixIcon: suffixIcon,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey[600]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Color(0xFF6F4B99), width: 2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: Colors.grey[600]!),
        ),
        filled: true,
        fillColor: Colors.white10,
        labelStyle: const TextStyle(color: Colors.white70, fontSize: 12),
        hintStyle: const TextStyle(color: Colors.grey, fontSize: 12),
      ),
      style: const TextStyle(color: Colors.white, fontSize: 12),
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      validator: validator,
      obscureText: obscureText,
      textCapitalization: textCapitalization,
      onChanged: onChanged,
      maxLines: maxLines,
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _lastNameController.dispose();
    _emailController.dispose();
    _documentController.dispose();
    _cepController.dispose();
    _streetController.dispose();
    _numberController.dispose();
    _complementController.dispose();
    _neighborhoodController.dispose();
    _cityController.dispose();
    _stateController.dispose();
    _customMotiveController.dispose();
    super.dispose();
  }
}