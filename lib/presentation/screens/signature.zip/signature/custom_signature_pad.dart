import 'package:flutter/material.dart';
import 'dart:ui' as ui;

class CustomSignaturePad extends StatefulWidget {
  final Color backgroundColor;
  final Color strokeColor;
  final double strokeWidth;
  final Function()? onSignatureChanged;

  const CustomSignaturePad({
    super.key,
    this.backgroundColor = Colors.white,
    this.strokeColor = Colors.black,
    this.strokeWidth = 2.0,
    this.onSignatureChanged,
  });

  @override
  State<CustomSignaturePad> createState() => CustomSignaturePadState();
}

class CustomSignaturePadState extends State<CustomSignaturePad> {
  final List<Offset?> _points = <Offset?>[];
  bool _hasSignature = false;

  void clear() {
    setState(() {
      _points.clear();
      _hasSignature = false;
    });
    debugPrint('CustomSignaturePad: Cleared signature');
  }

  bool get hasSignature => _hasSignature;

  Future<ui.Image> toImage({double pixelRatio = 1.0}) async {
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    final size = context.size!;
    
    // Draw background
    final backgroundPaint = Paint()..color = widget.backgroundColor;
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), backgroundPaint);
    
    // Draw signature using path
    final path = Path();
    final paint = Paint()
      ..color = widget.strokeColor
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = widget.strokeWidth
      ..style = PaintingStyle.stroke;

    for (int i = 0; i < _points.length; i++) {
      if (_points[i] != null) {
        if (i == 0 || _points[i - 1] == null) {
          path.moveTo(_points[i]!.dx, _points[i]!.dy);
        } else {
          path.lineTo(_points[i]!.dx, _points[i]!.dy);
        }
      }
    }

    canvas.drawPath(path, paint);

    final picture = recorder.endRecording();
    return await picture.toImage(
      (size.width * pixelRatio).round(),
      (size.height * pixelRatio).round(),
    );
  }

  void _onPanStart(DragStartDetails details) {
    final RenderBox renderBox = context.findRenderObject() as RenderBox;
    final localPosition = renderBox.globalToLocal(details.globalPosition);
    
    debugPrint('CustomSignaturePad: Pan started at $localPosition');
    
    setState(() {
      _points.add(localPosition);
      if (!_hasSignature) {
        _hasSignature = true;
        widget.onSignatureChanged?.call();
        debugPrint('CustomSignaturePad: First signature detected, calling onSignatureChanged');
      }
    });
    
    debugPrint('CustomSignaturePad: Points after start: ${_points.length}');
  }

  void _onPanUpdate(DragUpdateDetails details) {
    final RenderBox renderBox = context.findRenderObject() as RenderBox;
    final localPosition = renderBox.globalToLocal(details.globalPosition);
    
    setState(() {
      _points.add(localPosition);
    });
    
    // Debug every 10th point to avoid spam
    if (_points.length % 10 == 0) {
      debugPrint('CustomSignaturePad: Pan update - ${_points.length} points, last point: $localPosition');
    }
  }

  void _onPanEnd(DragEndDetails details) {
    setState(() {
      _points.add(null); // Add null to separate strokes
    });
    debugPrint('CustomSignaturePad: Pan ended, total points: ${_points.length}');
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: widget.backgroundColor,
      child: GestureDetector(
        onPanStart: _onPanStart,
        onPanUpdate: _onPanUpdate,
        onPanEnd: _onPanEnd,
        child: RepaintBoundary(
          child: CustomPaint(
            painter: _SignaturePainter(_points, widget.strokeColor, widget.strokeWidth),
            size: Size.infinite,
            child: const SizedBox(
              width: double.infinity,
              height: double.infinity,
            ),
          ),
        ),
      ),
    );
  }
}

class _SignaturePainter extends CustomPainter {
  final List<Offset?> points;
  final Color strokeColor;
  final double strokeWidth;

  _SignaturePainter(this.points, this.strokeColor, this.strokeWidth);

  @override
  void paint(Canvas canvas, Size size) {
    if (points.isEmpty) {
      debugPrint('_SignaturePainter: No points to draw');
      return;
    }

    final paint = Paint()
      ..color = strokeColor
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke;

    final path = Path();
    int pathPoints = 0;
    
    for (int i = 0; i < points.length; i++) {
      if (points[i] != null) {
        if (i == 0 || points[i - 1] == null) {
          // Start new stroke
          path.moveTo(points[i]!.dx, points[i]!.dy);
          pathPoints++;
        } else {
          // Continue stroke
          path.lineTo(points[i]!.dx, points[i]!.dy);
          pathPoints++;
        }
      }
    }

    canvas.drawPath(path, paint);
    
    // Debug paint calls
    if (pathPoints > 0) {
      debugPrint('_SignaturePainter: Drew path with $pathPoints points from ${points.length} total points');
    }
  }

  @override
  bool shouldRepaint(_SignaturePainter oldDelegate) {
    // Force repaint on every change to ensure real-time drawing
    return true;
  }
}