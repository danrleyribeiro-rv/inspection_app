import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_signaturepad/signaturepad.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'custom_signature_pad.dart';

class SignaturePadDialog extends StatefulWidget {
  const SignaturePadDialog({super.key});

  @override
  State<SignaturePadDialog> createState() => _SignaturePadDialogState();
}

class _SignaturePadDialogState extends State<SignaturePadDialog> {
  final GlobalKey<SfSignaturePadState> _syncfusionPadKey = GlobalKey();
  final GlobalKey<CustomSignaturePadState> _customPadKey = GlobalKey();
  bool _hasSignature = false;
  bool _useCustomPad = true; // Start with custom pad that should work

  void _onSignatureDrawn() {
    setState(() {
      _hasSignature = true;
    });
  }

  void _clearSignature() {
    if (_useCustomPad) {
      _customPadKey.currentState?.clear();
    } else {
      _syncfusionPadKey.currentState?.clear();
    }
    setState(() {
      _hasSignature = false;
    });
  }

  void _switchToPad() {
    setState(() {
      _useCustomPad = !_useCustomPad;
      _hasSignature = false;
    });
  }

  Future<String?> _saveSignature() async {
    try {
      ui.Image? signatureImage;

      if (_useCustomPad) {
        final customState = _customPadKey.currentState;
        if (customState == null) return null;
        signatureImage = await customState.toImage(pixelRatio: 3.0);
      } else {
        final syncfusionState = _syncfusionPadKey.currentState;
        if (syncfusionState == null) return null;
        signatureImage = await syncfusionState.toImage(pixelRatio: 3.0);
      }

      final ByteData? byteData = await signatureImage.toByteData(
        format: ui.ImageByteFormat.png,
      );

      if (byteData == null) return null;

      // Get temporary directory
      final directory = await getTemporaryDirectory();
      final signatureDir = Directory('${directory.path}/signatures');
      
      // Create directory if it doesn't exist
      if (!await signatureDir.exists()) {
        await signatureDir.create(recursive: true);
      }

      // Create file path with timestamp
      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final filePath = '${signatureDir.path}/signature_$timestamp.png';

      // Save the file
      final file = File(filePath);
      await file.writeAsBytes(byteData.buffer.asUint8List());

      return filePath;
    } catch (e) {
      debugPrint('Error saving signature: $e');
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(8),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.98,
        height: MediaQuery.of(context).size.height * 0.9,
        decoration: BoxDecoration(
          color: const Color(0xFF312456),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFF6F4B99), width: 2),
        ),
        child: Column(
          children: [
            // Header
            Container(
              padding: const EdgeInsets.all(12),
              decoration: const BoxDecoration(
                color: Color(0xFF6F4B99),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(14),
                  topRight: Radius.circular(14),
                ),
              ),
              child: Row(
                children: [
                  const Icon(Icons.edit, color: Colors.white, size: 20),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text(
                      'Coleta de Assinatura',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  // Switch pad button
                  IconButton(
                    onPressed: _switchToPad,
                    icon: Icon(
                      _useCustomPad ? Icons.touch_app : Icons.draw,
                      color: Colors.white,
                      size: 18,
                    ),
                    tooltip: _useCustomPad ? 'Usar pad avançado' : 'Usar pad básico',
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: const Icon(Icons.close, color: Colors.white, size: 20),
                  ),
                ],
              ),
            ),

            // Instructions
            Padding(
              padding: const EdgeInsets.all(12),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.blue.withAlpha((255 * 0.1).round()),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.blue.withAlpha((255 * 0.3).round())),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.info_outline, color: Colors.blue, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Usando pad ${_useCustomPad ? 'básico' : 'avançado'}. Assine na área branca abaixo.',
                        style: const TextStyle(
                          color: Colors.blue,
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Signature Pad
            Expanded(
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey[300]!, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.1),
                      spreadRadius: 1,
                      blurRadius: 5,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: _useCustomPad ? 
                    // Custom SignaturePad
                    CustomSignaturePad(
                      key: _customPadKey,
                      backgroundColor: Colors.white,
                      strokeColor: Colors.black87,
                      strokeWidth: 3.0,
                      onSignatureChanged: _onSignatureDrawn,
                    ) :
                    // Syncfusion SignaturePad
                    SfSignaturePad(
                      key: _syncfusionPadKey,
                      backgroundColor: Colors.white,
                      strokeColor: Colors.black87,
                      minimumStrokeWidth: 2.0,
                      maximumStrokeWidth: 4.0,
                      onDrawStart: () {
                        _onSignatureDrawn();
                        return true;
                      },
                    ),
                ),
              ),
            ),

            // Status indicator
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _hasSignature 
                    ? Colors.green.withAlpha((255 * 0.1).round())
                    : Colors.grey.withAlpha((255 * 0.1).round()),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: _hasSignature ? Colors.green : Colors.grey,
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      _hasSignature ? Icons.check_circle : Icons.circle_outlined,
                      size: 14,
                      color: _hasSignature ? Colors.green : Colors.grey,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _hasSignature ? 'Assinatura detectada' : 'Aguardando assinatura',
                      style: TextStyle(
                        fontSize: 10,
                        color: _hasSignature ? Colors.green : Colors.grey,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            // Action buttons
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  // Clear button
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _hasSignature ? _clearSignature : null,
                      icon: const Icon(Icons.clear, size: 16),
                      label: const Text('Limpar', style: TextStyle(fontSize: 12)),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.orange,
                        side: BorderSide(
                          color: _hasSignature ? Colors.orange : Colors.grey,
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  
                  // Save button
                  Expanded(
                    flex: 2,
                    child: ElevatedButton.icon(
                      onPressed: _hasSignature ? () async {
                        // Show loading
                        showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (context) => const Center(
                            child: CircularProgressIndicator(color: Colors.white),
                          ),
                        );

                        final filePath = await _saveSignature();
                        
                        // Hide loading
                        if (context.mounted) Navigator.of(context).pop();
                        
                        if (filePath != null && context.mounted) {
                          Navigator.of(context).pop(filePath);
                        } else if (context.mounted) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Erro ao salvar assinatura'),
                              backgroundColor: Colors.red,
                            ),
                          );
                        }
                      } : null,
                      icon: const Icon(Icons.save, size: 16),
                      label: const Text('Salvar Assinatura', style: TextStyle(fontSize: 12)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _hasSignature 
                          ? const Color(0xFF6F4B99) 
                          : Colors.grey,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}